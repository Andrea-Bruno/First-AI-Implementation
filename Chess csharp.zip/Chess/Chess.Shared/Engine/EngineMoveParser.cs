namespace Chess.Shared.Engine;

public static class EngineMoveParser
{
    public static bool TryParseEngineLine(string? line, out ChessMove move)
    {
        move = default;

        if (string.IsNullOrWhiteSpace(line))
        {
            return false;
        }

        var trimmed = line.Trim();
        if (!TryExtractMoveToken(trimmed, out var token))
        {
            return false;
        }

        return TryParseMoveToken(token, out move);
    }

    public static bool TryParseLatestMove(IEnumerable<string> lines, out ChessMove move)
    {
        move = default;
        var found = false;

        foreach (var line in lines)
        {
            if (TryParseEngineLine(line, out var parsed))
            {
                move = parsed;
                found = true;
            }
        }

        return found;
    }

    private static bool TryExtractMoveToken(string line, out string token)
    {
        token = string.Empty;

        if (line.StartsWith("move ", StringComparison.OrdinalIgnoreCase))
        {
            token = line[5..].Trim();
            return token.Length >= 4;
        }

        var firstSpace = line.IndexOf(' ');
        var dot = line.IndexOf('.');
        var startsWithNumber = line.Length > 0 && char.IsDigit(line[0]);

        if (startsWithNumber && dot >= 0 && firstSpace >= 0 && dot < firstSpace)
        {
            token = line[(line.LastIndexOf(' ') + 1)..].Trim();
            return token.Length >= 4;
        }

        return false;
    }

    public static bool TryParseMoveToken(string token, out ChessMove move)
    {
        move = default;

        if (token.Length < 4)
        {
            return false;
        }

        if (!BoardPosition.TryParse(token[0], token[1], out var from))
        {
            return false;
        }

        if (!BoardPosition.TryParse(token[2], token[3], out var to))
        {
            return false;
        }

        var promotion = PieceType.None;
        if (token.Length > 4)
        {
            promotion = char.ToLowerInvariant(token[4]) switch
            {
                'q' => PieceType.Queen,
                'r' => PieceType.Rook,
                'b' => PieceType.Bishop,
                'n' => PieceType.Knight,
                _ => PieceType.None
            };
        }

        move = new ChessMove(from, to, promotion);
        return true;
    }
}