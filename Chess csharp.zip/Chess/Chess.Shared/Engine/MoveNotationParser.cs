using System.Text.RegularExpressions;

namespace Chess.Shared.Engine;

public static partial class MoveNotationParser
{
    public static bool TryParseMoveToken(string token, BoardPiece[,] board, PieceColor sideToMove, out ChessMove move)
    {
        move = default;

        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }

        if (EngineMoveParser.TryParseMoveToken(token.Trim(), out move))
        {
            return true;
        }

        var normalized = NormalizeSan(token);
        if (string.IsNullOrWhiteSpace(normalized))
        {
            return false;
        }

        if (TryParseCastle(normalized, board, sideToMove, out move))
        {
            return true;
        }

        return TryParseStandardSan(normalized, board, sideToMove, out move);
    }

    private static bool TryParseStandardSan(string san, BoardPiece[,] board, PieceColor sideToMove, out ChessMove move)
    {
        move = default;

        var destinationMatch = DestinationRegex().Match(san);
        if (!destinationMatch.Success)
        {
            return false;
        }

        var destinationText = destinationMatch.Value;
        if (!BoardPosition.TryParse(destinationText[0], destinationText[1], out var destination))
        {
            return false;
        }

        var prefix = san[..destinationMatch.Index];
        var promotion = ExtractPromotion(san);

        var pieceType = PieceType.Pawn;
        if (prefix.Length > 0)
        {
            var p = prefix[0];
            pieceType = p switch
            {
                'K' => PieceType.King,
                'Q' => PieceType.Queen,
                'R' => PieceType.Rook,
                'B' => PieceType.Bishop,
                'N' => PieceType.Knight,
                _ => PieceType.Pawn
            };

            if (pieceType != PieceType.Pawn)
            {
                prefix = prefix[1..];
            }
        }

        var isCapture = prefix.Contains('x', StringComparison.Ordinal);
        prefix = prefix.Replace("x", string.Empty, StringComparison.Ordinal);
        var disambiguation = prefix;

        var candidates = FindCandidateStarts(board, sideToMove, pieceType, destination, isCapture);
        candidates = ApplyDisambiguation(candidates, disambiguation);

        if (candidates.Count != 1)
        {
            return false;
        }

        move = new ChessMove(candidates[0], destination, promotion);
        return true;
    }

    private static List<BoardPosition> FindCandidateStarts(
        BoardPiece[,] board,
        PieceColor sideToMove,
        PieceType pieceType,
        BoardPosition destination,
        bool isCapture)
    {
        var candidates = new List<BoardPosition>();

        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                var piece = board[file, rank];
                if (piece.Color != sideToMove || piece.Type != pieceType)
                {
                    continue;
                }

                var from = new BoardPosition(file, rank);
                if (CanReach(board, from, destination, piece, isCapture))
                {
                    candidates.Add(from);
                }
            }
        }

        return candidates;
    }

    private static List<BoardPosition> ApplyDisambiguation(List<BoardPosition> candidates, string disambiguation)
    {
        if (string.IsNullOrWhiteSpace(disambiguation) || candidates.Count <= 1)
        {
            return candidates;
        }

        return candidates
            .Where(pos => MatchesDisambiguation(pos, disambiguation))
            .ToList();
    }

    private static bool MatchesDisambiguation(BoardPosition position, string disambiguation)
    {
        if (disambiguation.Length == 1)
        {
            var c = disambiguation[0];
            if (char.IsLetter(c))
            {
                return position.File == char.ToLowerInvariant(c) - 'a';
            }

            if (char.IsDigit(c))
            {
                return position.Rank == c - '1';
            }
        }
        else if (disambiguation.Length >= 2)
        {
            var file = disambiguation.FirstOrDefault(char.IsLetter);
            var rank = disambiguation.FirstOrDefault(char.IsDigit);

            var fileMatch = file == default || position.File == char.ToLowerInvariant(file) - 'a';
            var rankMatch = rank == default || position.Rank == rank - '1';
            return fileMatch && rankMatch;
        }

        return false;
    }

    private static bool CanReach(BoardPiece[,] board, BoardPosition from, BoardPosition to, BoardPiece piece, bool isCapture)
    {
        if (!to.IsValid || !from.IsValid || from.Equals(to))
        {
            return false;
        }

        var target = board[to.File, to.Rank];
        if (target.Color == piece.Color)
        {
            return false;
        }

        var fileDiff = to.File - from.File;
        var rankDiff = to.Rank - from.Rank;

        return piece.Type switch
        {
            PieceType.Pawn => CanPawnReach(board, from, to, piece.Color, isCapture),
            PieceType.Knight => (Math.Abs(fileDiff), Math.Abs(rankDiff)) is (1, 2) or (2, 1),
            PieceType.Bishop => Math.Abs(fileDiff) == Math.Abs(rankDiff) && IsPathClear(board, from, to),
            PieceType.Rook => (fileDiff == 0 || rankDiff == 0) && IsPathClear(board, from, to),
            PieceType.Queen => (fileDiff == 0 || rankDiff == 0 || Math.Abs(fileDiff) == Math.Abs(rankDiff)) && IsPathClear(board, from, to),
            PieceType.King => Math.Abs(fileDiff) <= 1 && Math.Abs(rankDiff) <= 1,
            _ => false
        };
    }

    private static bool CanPawnReach(BoardPiece[,] board, BoardPosition from, BoardPosition to, PieceColor color, bool isCapture)
    {
        var fileDiff = to.File - from.File;
        var rankDiff = to.Rank - from.Rank;
        var direction = color == PieceColor.White ? 1 : -1;
        var startRank = color == PieceColor.White ? 1 : 6;
        var target = board[to.File, to.Rank];

        if (isCapture)
        {
            return Math.Abs(fileDiff) == 1 && rankDiff == direction && target.Color != PieceColor.None && target.Color != color;
        }

        if (fileDiff != 0 || target.Color != PieceColor.None)
        {
            return false;
        }

        if (rankDiff == direction)
        {
            return true;
        }

        if (from.Rank == startRank && rankDiff == 2 * direction)
        {
            var middleRank = from.Rank + direction;
            return board[from.File, middleRank].Color == PieceColor.None;
        }

        return false;
    }

    private static bool IsPathClear(BoardPiece[,] board, BoardPosition from, BoardPosition to)
    {
        var stepFile = Math.Sign(to.File - from.File);
        var stepRank = Math.Sign(to.Rank - from.Rank);

        var file = from.File + stepFile;
        var rank = from.Rank + stepRank;

        while (file != to.File || rank != to.Rank)
        {
            if (board[file, rank].Color != PieceColor.None)
            {
                return false;
            }

            file += stepFile;
            rank += stepRank;
        }

        return true;
    }

    private static bool TryParseCastle(string san, BoardPiece[,] board, PieceColor sideToMove, out ChessMove move)
    {
        move = default;
        var text = san.Replace('0', 'O');
        if (text != "O-O" && text != "O-O-O")
        {
            return false;
        }

        var rank = sideToMove == PieceColor.White ? 0 : 7;
        var kingStart = FindKing(board, sideToMove);
        if (kingStart is null)
        {
            return false;
        }

        var targetFile = text == "O-O" ? 6 : 2;
        var destination = new BoardPosition(targetFile, rank);
        move = new ChessMove(kingStart.Value, destination);
        return true;
    }

    private static BoardPosition? FindKing(BoardPiece[,] board, PieceColor side)
    {
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                var piece = board[file, rank];
                if (piece.Color == side && piece.Type == PieceType.King)
                {
                    return new BoardPosition(file, rank);
                }
            }
        }

        return null;
    }

    private static PieceType ExtractPromotion(string san)
    {
        var promotionMatch = PromotionRegex().Match(san);
        if (!promotionMatch.Success)
        {
            return PieceType.None;
        }

        var symbol = promotionMatch.Groups[1].Value;
        return symbol switch
        {
            "Q" => PieceType.Queen,
            "R" => PieceType.Rook,
            "B" => PieceType.Bishop,
            "N" => PieceType.Knight,
            _ => PieceType.None
        };
    }

    private static string NormalizeSan(string token)
    {
        var text = token.Trim();
        text = AnnotationRegex().Replace(text, string.Empty);
        text = CheckSuffixRegex().Replace(text, string.Empty);
        text = text.Replace("e.p.", string.Empty, StringComparison.OrdinalIgnoreCase);
        return text.Trim();
    }

    [GeneratedRegex("([a-h][1-8])")]
    private static partial Regex DestinationRegex();

    [GeneratedRegex("=([QRBN])")]
    private static partial Regex PromotionRegex();

    [GeneratedRegex("[!?]+")]
    private static partial Regex AnnotationRegex();

    [GeneratedRegex("[+#]+$")]
    private static partial Regex CheckSuffixRegex();
}