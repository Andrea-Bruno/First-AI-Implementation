namespace Chess.Shared.Engine;

public enum PieceColor
{
    None = 0,
    White = 1,
    Black = 2
}

public enum PieceType
{
    None = 0,
    Pawn = 1,
    Knight = 2,
    Bishop = 3,
    Rook = 4,
    Queen = 5,
    King = 6
}

public readonly record struct BoardPosition(int File, int Rank)
{
    public bool IsValid => File is >= 0 and <= 7 && Rank is >= 0 and <= 7;

    public static bool TryParse(char file, char rank, out BoardPosition position)
    {
        position = default;

        var normalizedFile = char.ToLowerInvariant(file);
        if (normalizedFile is < 'a' or > 'h')
        {
            return false;
        }

        if (rank is < '1' or > '8')
        {
            return false;
        }

        position = new BoardPosition(normalizedFile - 'a', rank - '1');
        return true;
    }

    public override string ToString()
    {
        if (!IsValid)
        {
            return "??";
        }

        return $"{(char)('a' + File)}{Rank + 1}";
    }
}

public readonly record struct ChessMove(BoardPosition From, BoardPosition To, PieceType Promotion = PieceType.None)
{
    public bool IsValid => From.IsValid && To.IsValid;

    public override string ToString()
    {
        if (!IsValid)
        {
            return string.Empty;
        }

        var promotion = Promotion == PieceType.None
            ? string.Empty
            : Promotion switch
            {
                PieceType.Queen => "q",
                PieceType.Rook => "r",
                PieceType.Bishop => "b",
                PieceType.Knight => "n",
                _ => string.Empty
            };

        return $"{From}{To}{promotion}";
    }
}

public readonly record struct BoardPiece(PieceType Type, PieceColor Color)
{
    public static BoardPiece Empty => new(PieceType.None, PieceColor.None);

    public bool IsEmpty => Type == PieceType.None;
}