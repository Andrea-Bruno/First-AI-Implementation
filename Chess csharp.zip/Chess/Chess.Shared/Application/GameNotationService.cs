using System.Text;
using System.Text.RegularExpressions;
using Chess.Shared.Engine;

namespace Chess.Shared.Application;

public static partial class GameNotationService
{
    public static IReadOnlyList<ImportedPgn> ParsePgnCollection(string text)
    {
        var result = new List<ImportedPgn>();
        if (string.IsNullOrWhiteSpace(text))
        {
            return result;
        }

        var normalized = text.Replace("\r\n", "\n");
        var matches = CollectionSplitRegex().Matches(normalized);
        if (matches.Count == 0)
        {
            var single = ParsePgn(text);
            single.RawText = text.Trim();
            result.Add(single);
            return result;
        }

        foreach (Match match in matches)
        {
            if (!match.Success)
            {
                continue;
            }

            var chunk = match.Value.Trim();
            if (!string.IsNullOrWhiteSpace(chunk))
            {
                var game = ParsePgn(chunk);
                game.RawText = chunk;
                result.Add(game);
            }
        }

        return result;
    }

    public static string ExportFen(BoardPiece[,] board, PieceColor activeTurn, int fullMoveNumber)
    {
        var fenRows = new List<string>(8);

        for (var rank = 7; rank >= 0; rank--)
        {
            var row = new StringBuilder();
            var emptySquares = 0;

            for (var file = 0; file < 8; file++)
            {
                var piece = board[file, rank];
                if (piece.IsEmpty)
                {
                    emptySquares++;
                    continue;
                }

                if (emptySquares > 0)
                {
                    row.Append(emptySquares);
                    emptySquares = 0;
                }

                row.Append(ToFenPiece(piece));
            }

            if (emptySquares > 0)
            {
                row.Append(emptySquares);
            }

            fenRows.Add(row.ToString());
        }

        var sideToMove = activeTurn == PieceColor.Black ? "b" : "w";
        var normalizedFullMove = Math.Max(1, fullMoveNumber);
        return $"{string.Join('/', fenRows)} {sideToMove} - - 0 {normalizedFullMove}";
    }

    public static bool TryImportFen(string fenText, out BoardPiece[,] board, out PieceColor activeTurn)
    {
        board = new BoardPiece[8, 8];
        activeTurn = PieceColor.White;

        if (string.IsNullOrWhiteSpace(fenText))
        {
            return false;
        }

        var fenParts = fenText.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (fenParts.Length < 2)
        {
            return false;
        }

        var ranks = fenParts[0].Split('/');
        if (ranks.Length != 8)
        {
            return false;
        }

        for (var rankIndex = 0; rankIndex < 8; rankIndex++)
        {
            var rank = 7 - rankIndex;
            var file = 0;

            foreach (var symbol in ranks[rankIndex])
            {
                if (char.IsDigit(symbol))
                {
                    file += symbol - '0';
                    continue;
                }

                if (file > 7)
                {
                    return false;
                }

                board[file, rank] = FromFenPiece(symbol);
                file++;
            }

            if (file != 8)
            {
                return false;
            }
        }

        activeTurn = fenParts[1].Equals("b", StringComparison.OrdinalIgnoreCase)
            ? PieceColor.Black
            : PieceColor.White;

        return true;
    }

    public static string ExportPgn(GameMetadata metadata, IReadOnlyList<MoveRecord> moves, string fen)
    {
        var tags = new Dictionary<string, string>
        {
            ["Event"] = NormalizeTagValue(metadata.EventNotes),
            ["Site"] = NormalizeTagValue(metadata.Location),
            ["Date"] = NormalizeTagValue(metadata.EventDate),
            ["Time"] = NormalizeTagValue(metadata.EventTime),
            ["Round"] = NormalizeTagValue(metadata.Round),
            ["Board"] = NormalizeTagValue(metadata.BoardNumber),
            ["Match"] = NormalizeTagValue(metadata.MatchNumber),
            ["White"] = NormalizeTagValue(metadata.WhitePlayer.Name),
            ["Black"] = NormalizeTagValue(metadata.BlackPlayer.Name),
            ["Result"] = NormalizeTagValue(NormalizeResult(metadata.Result)),
            ["ECO"] = NormalizeTagValue(metadata.EcoCode),
            ["NIC"] = NormalizeTagValue(metadata.NicCode),
            ["WhiteElo"] = NormalizeTagValue(metadata.WhitePlayer.Elo),
            ["BlackElo"] = NormalizeTagValue(metadata.BlackPlayer.Elo),
            ["WhiteUSCF"] = NormalizeTagValue(metadata.WhitePlayer.Uscf),
            ["BlackUSCF"] = NormalizeTagValue(metadata.BlackPlayer.Uscf),
            ["WhiteTitle"] = NormalizeTagValue(metadata.WhitePlayer.Title),
            ["BlackTitle"] = NormalizeTagValue(metadata.BlackPlayer.Title),
            ["WhiteNA"] = NormalizeTagValue(metadata.WhitePlayer.Email),
            ["BlackNA"] = NormalizeTagValue(metadata.BlackPlayer.Email),
            ["WhiteType"] = NormalizeTagValue(metadata.WhitePlayer.PlayerType),
            ["BlackType"] = NormalizeTagValue(metadata.BlackPlayer.PlayerType),
            ["WhiteCountry"] = NormalizeTagValue(metadata.WhitePlayer.Country),
            ["BlackCountry"] = NormalizeTagValue(metadata.BlackPlayer.Country),
            ["Section"] = NormalizeTagValue(NormalizeSession(metadata.Session)),
            ["Termination"] = NormalizeTagValue(NormalizeTermination(metadata.Termination)),
            ["Mode"] = NormalizeTagValue(NormalizeMode(metadata.PlayMode)),
            ["Opening"] = NormalizeTagValue(metadata.Opening),
            ["Variation"] = NormalizeTagValue(metadata.SubOpening),
            ["SubVariation"] = NormalizeTagValue(metadata.Variation),
            ["Annotator"] = NormalizeTagValue(metadata.Annotator),
            ["EventSponsor"] = NormalizeTagValue(metadata.Sponsor),
            ["FEN"] = fen
        };

        var builder = new StringBuilder();
        foreach (var (tag, value) in tags)
        {
            builder.Append('[').Append(tag).Append(" \"").Append(value).AppendLine("\"]");
        }

        builder.AppendLine();

        for (var index = 0; index < moves.Count; index++)
        {
            if (index % 2 == 0)
            {
                builder.Append(index / 2 + 1).Append(". ");
            }

            builder.Append(moves[index].Notation).Append(' ');
            if (!string.IsNullOrWhiteSpace(moves[index].Comment))
            {
                builder.Append('{').Append(moves[index].Comment.Trim()).Append("} ");
            }
        }

        var normalizedResult = NormalizeResult(metadata.Result);
        if (!string.IsNullOrWhiteSpace(normalizedResult))
        {
            builder.Append(normalizedResult);
        }

        return builder.ToString().TrimEnd();
    }

    public static ImportedPgn ParsePgn(string pgnText)
    {
        var result = new ImportedPgn();
        if (string.IsNullOrWhiteSpace(pgnText))
        {
            return result;
        }

        var tags = TagRegex().Matches(pgnText);
        foreach (Match match in tags)
        {
            if (match.Groups.Count < 3)
            {
                continue;
            }

            var key = match.Groups[1].Value.Trim();
            var value = match.Groups[2].Value.Trim();
            if (!string.IsNullOrWhiteSpace(key))
            {
                result.Tags[key] = value;
            }
        }

        var body = TagRegex().Replace(pgnText, " ");
        var parts = PgnPartsRegex().Matches(body);

        foreach (Match part in parts)
        {
            if (!part.Success)
            {
                continue;
            }

            var raw = part.Value;
            if (raw.StartsWith("{", StringComparison.Ordinal) || raw.StartsWith(";", StringComparison.Ordinal))
            {
                var comment = NormalizeComment(raw);
                if (string.IsNullOrWhiteSpace(comment))
                {
                    continue;
                }

                if (result.MoveEntries.Count == 0)
                {
                    if (string.IsNullOrWhiteSpace(result.LeadingComment))
                    {
                        result.LeadingComment = comment;
                    }
                    else
                    {
                        result.LeadingComment = $"{result.LeadingComment}{Environment.NewLine}{comment}";
                    }
                }
                else
                {
                    var last = result.MoveEntries[^1];
                    if (string.IsNullOrWhiteSpace(last.Comment))
                    {
                        last.Comment = comment;
                    }
                    else
                    {
                        last.Comment = $"{last.Comment}{Environment.NewLine}{comment}";
                    }
                }

                continue;
            }

            var normalized = NormalizeMoveToken(raw);
            if (string.IsNullOrWhiteSpace(normalized))
            {
                continue;
            }

            if (normalized.EndsWith('.'))
            {
                continue;
            }

            if (normalized is "1-0" or "0-1" or "1/2-1/2" or "*")
            {
                result.ResultToken = normalized;
                continue;
            }

            result.MoveEntries.Add(new ImportedMoveEntry
            {
                Token = normalized
            });
        }

        result.MoveTokens.AddRange(result.MoveEntries.Select(entry => entry.Token));
        return result;
    }

    private static string NormalizeMoveToken(string token)
    {
        var normalized = token.Trim();
        normalized = MoveNumberPrefixRegex().Replace(normalized, string.Empty);
        if (normalized.StartsWith("$", StringComparison.Ordinal))
        {
            return string.Empty;
        }

        if (normalized == "...")
        {
            return string.Empty;
        }

        return normalized;
    }

    private static string NormalizeComment(string rawComment)
    {
        var trimmed = rawComment.Trim();
        if (trimmed.StartsWith("{", StringComparison.Ordinal) && trimmed.EndsWith("}", StringComparison.Ordinal) && trimmed.Length >= 2)
        {
            trimmed = trimmed[1..^1];
        }
        else if (trimmed.StartsWith(";", StringComparison.Ordinal))
        {
            trimmed = trimmed[1..];
        }

        return trimmed.Trim();
    }

    private static string NormalizeTagValue(string value)
    {
        return string.IsNullOrWhiteSpace(value) ? "?" : value.Trim();
    }

    private static string NormalizeSession(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "OPEN" => "OPEN",
            "INTERNAL" => "RESERVE",
            _ => value
        };
    }

    private static string NormalizeTermination(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "TIME FORFEIT" => "TIMES FORFEIT",
            "RULES INFRACTION" => "RULES INFRACTION",
            "NORMAL" => "NORMAL",
            _ => value
        };
    }

    private static string NormalizeMode(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "OVER THE BOARD" => "OTB",
            "POSTAL" => "PM",
            "EMAIL" => "EM",
            "INTERNET SERVER" => "ICS",
            "NON-STANDARD BOARD" => "TC",
            _ => value
        };
    }

    private static string NormalizeResult(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "WHITE WIN" => "1-0",
            "BLACK WIN" => "0-1",
            "DRAW" => "1/2-1/2",
            _ => value
        };
    }

    private static char ToFenPiece(BoardPiece piece)
    {
        var basePiece = piece.Type switch
        {
            PieceType.King => 'k',
            PieceType.Queen => 'q',
            PieceType.Rook => 'r',
            PieceType.Bishop => 'b',
            PieceType.Knight => 'n',
            PieceType.Pawn => 'p',
            _ => '1'
        };

        return piece.Color == PieceColor.White ? char.ToUpperInvariant(basePiece) : basePiece;
    }

    private static BoardPiece FromFenPiece(char symbol)
    {
        var color = char.IsUpper(symbol) ? PieceColor.White : PieceColor.Black;
        var type = char.ToLowerInvariant(symbol) switch
        {
            'k' => PieceType.King,
            'q' => PieceType.Queen,
            'r' => PieceType.Rook,
            'b' => PieceType.Bishop,
            'n' => PieceType.Knight,
            'p' => PieceType.Pawn,
            _ => PieceType.None
        };

        return type == PieceType.None ? BoardPiece.Empty : new BoardPiece(type, color);
    }

    [GeneratedRegex("\\[(\\w+)\\s+\"([^\"]*)\"\\]")]
    private static partial Regex TagRegex();

    [GeneratedRegex("^\\d+\\.{1,3}")]
    private static partial Regex MoveNumberPrefixRegex();

    [GeneratedRegex("\\{[^}]*\\}|;[^\\r\\n]*|[^\\s]+")]
    private static partial Regex PgnPartsRegex();

    [GeneratedRegex("(?ms)^\\[Event\\s+\".*?(?=^\\[Event\\s+\"|\\z)")]
    private static partial Regex CollectionSplitRegex();
}

public sealed class ImportedPgn
{
    public Dictionary<string, string> Tags { get; } = new(StringComparer.OrdinalIgnoreCase);

    public List<string> MoveTokens { get; } = [];

    public List<ImportedMoveEntry> MoveEntries { get; } = [];

    public string ResultToken { get; set; } = string.Empty;

    public string LeadingComment { get; set; } = string.Empty;

    public string RawText { get; set; } = string.Empty;
}

public sealed class ImportedMoveEntry
{
    public string Token { get; set; } = string.Empty;

    public string Comment { get; set; } = string.Empty;
}