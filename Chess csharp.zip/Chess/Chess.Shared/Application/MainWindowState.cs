using Chess.Shared.Engine;
using System.IO;

namespace Chess.Shared.Application;

public sealed class MainWindowState
{
    private BoardPosition? selectedSquare;
    private DateTime activeTurnStartedUtc;
    private TimeSpan whiteElapsed = TimeSpan.Zero;
    private TimeSpan blackElapsed = TimeSpan.Zero;
    private int appliedMoveCount;
    private readonly BoardPiece[,] initialBoard = new BoardPiece[8, 8];
    private PieceColor initialTurn = PieceColor.White;
    private int currentPly;

    public MainWindowState()
    {
        Board = new BoardPiece[8, 8];
        NewGame();
    }

    public BoardPiece[,] Board { get; }

    public IReadOnlyList<MoveRecord> MoveHistory => moveHistory;

    public IReadOnlyList<string> EngineThoughtLines => engineThoughtLines;

    public string EngineOutput { get; private set; } = "Engine idle.";

    public string StatusText { get; private set; } = "Ready.";

    public PieceColor ActiveTurn { get; private set; } = PieceColor.White;

    public int ReflectionMinutes { get; private set; }

    public int MovesPerTimeControl { get; private set; }

    public int BonusSecondsPerMove { get; private set; }

    public bool WhiteTimeExpired { get; private set; }

    public bool BlackTimeExpired { get; private set; }

    public string WhiteClockText => FormatClock(GetRemainingTime(PieceColor.White));

    public string BlackClockText => FormatClock(GetRemainingTime(PieceColor.Black));

    public GameMetadata Metadata { get; } = new();

    public int SelectedMoveIndex { get; private set; } = -1;

    public int CurrentPly => currentPly;

    public IReadOnlyList<ArchiveGameSummary> ArchiveEntries => archiveEntries;

    public int SelectedArchiveIndex { get; private set; } = -1;

    public string ArchiveSearchText { get; set; } = string.Empty;

    public bool IsArchiveLoading { get; private set; }

    public int ArchiveProgressMin { get; private set; }

    public int ArchiveProgressMax { get; private set; }

    public int ArchiveProgressValue { get; private set; }

    public string ArchiveProgressText => $"{ArchiveProgressValue}/{ArchiveProgressMax}";

    public string ArchiveEstimatedRemainingText { get; private set; } = "00:00:00";

    public IReadOnlyList<string> PieceSetOptions { get; } =
    [
        "Classic",
        "Wood",
        "Marble",
        "Modern"
    ];

    public string SelectedPieceSet { get; private set; } = "Classic";

    public string LastExtraOperation { get; private set; } = "None";

    public string LegacyApplicationRootPath { get; private set; } = ResolveLegacyApplicationRootPath();

    public string EngineBinaryPath { get; private set; } = string.Empty;

    public bool IsEngineAvailable => !string.IsNullOrWhiteSpace(EngineBinaryPath);

    public bool IsEngineComputationRunning { get; private set; }

    public bool IsEngineMoveCommandEnabled => !IsEngineComputationRunning;

    public bool IsAwaitingPromotionSelection { get; private set; }

    public bool IsGameFinished { get; private set; }

    public string GameFinishedReason { get; private set; } = string.Empty;

    public bool IsBoardInteractionEnabled => !IsGameFinished && !IsAwaitingPromotionSelection && SelectedEditabilityIndex != 0;

    public bool ShowBoardCoordinates { get; private set; }

    public bool UseBorderSelection { get; private set; } = true;

    public bool UseSurfaceHighlight { get; private set; }

    public IReadOnlyList<string> EditabilityOptions { get; } =
    [
        "Locked",
        "Edit mode",
        "White to move",
        "Black to move"
    ];

    public int SelectedEditabilityIndex { get; private set; }

    public AnalysisTreeNode AnalysisRoot => BuildAnalysisTree();

    public string SelectedMoveComment => SelectedMoveIndex >= 0 && SelectedMoveIndex < moveHistory.Count
        ? moveHistory[SelectedMoveIndex].Comment
        : string.Empty;

    public BoardPosition? SelectedSquare => selectedSquare;

    private readonly List<MoveRecord> moveHistory = [];
    private readonly List<string> engineThoughtLines = [];
    private readonly List<ArchiveGameSummary> archiveEntries = [];
    private readonly List<ImportedPgn> archiveGames = [];
    private DateTime archiveLoadStartedUtc;
    private ChessMove? pendingPromotionMove;
    private BoardPiece[,]? clipboardBoard;
    private PieceColor clipboardTurn;

    public void NewGame()
    {
        Array.Clear(Board);
        moveHistory.Clear();
        engineThoughtLines.Clear();
        selectedSquare = null;
        EngineOutput = "Engine idle.";
        StatusText = "New game created.";
        ActiveTurn = PieceColor.White;
        activeTurnStartedUtc = DateTime.UtcNow;
        whiteElapsed = TimeSpan.Zero;
        blackElapsed = TimeSpan.Zero;
        appliedMoveCount = 0;
        WhiteTimeExpired = false;
        BlackTimeExpired = false;
        SelectedMoveIndex = -1;
        Metadata.Reset();
        archiveEntries.Clear();
        archiveGames.Clear();
        SelectedArchiveIndex = -1;
        ArchiveSearchText = string.Empty;
        IsArchiveLoading = false;
        ArchiveProgressMin = 0;
        ArchiveProgressMax = 0;
        ArchiveProgressValue = 0;
        ArchiveEstimatedRemainingText = "00:00:00";
        SelectedPieceSet = "Classic";
        LastExtraOperation = "None";
        IsEngineComputationRunning = false;
        IsAwaitingPromotionSelection = false;
        IsGameFinished = false;
        GameFinishedReason = string.Empty;
        pendingPromotionMove = null;
        ShowBoardCoordinates = false;
        UseBorderSelection = true;
        UseSurfaceHighlight = false;
        SelectedEditabilityIndex = 0;
        RefreshEngineBinding();

        ConfigureTimeControl(ReflectionMinutes, MovesPerTimeControl, BonusSecondsPerMove);

        PlaceBackRank(0, PieceColor.White);
        PlacePawns(1, PieceColor.White);
        PlacePawns(6, PieceColor.Black);
        PlaceBackRank(7, PieceColor.Black);
        CaptureInitialPosition();
        currentPly = 0;
        StatusText = "New game created.";
    }

    public string ExportFenText()
    {
        return GameNotationService.ExportFen(Board, ActiveTurn, GetCurrentFullMoveNumber());
    }

    public string ExportPgnText()
    {
        var fen = ExportFenText();
        return GameNotationService.ExportPgn(Metadata, moveHistory, fen);
    }

    public void ImportFenText(string fenText)
    {
        if (!GameNotationService.TryImportFen(fenText, out var importedBoard, out var importedTurn))
        {
            StatusText = "Invalid FEN input.";
            return;
        }

        NewGame();
        LoadBoard(importedBoard, importedTurn);
        CaptureInitialPosition();
        currentPly = 0;
        moveHistory.Clear();
        SelectedMoveIndex = -1;
        StatusText = "FEN imported successfully.";
    }

    public void ImportPgnText(string pgnText)
    {
        var parsed = GameNotationService.ParsePgn(pgnText);
        NewGame();
        ApplyPgnTags(parsed.Tags);
        if (!string.IsNullOrWhiteSpace(parsed.LeadingComment))
        {
            Metadata.EventNotes = string.IsNullOrWhiteSpace(Metadata.EventNotes)
                ? parsed.LeadingComment
                : $"{Metadata.EventNotes}{Environment.NewLine}{parsed.LeadingComment}";
        }

        if (parsed.Tags.TryGetValue("FEN", out var fenTag) &&
            GameNotationService.TryImportFen(fenTag, out var importedBoard, out var importedTurn))
        {
            LoadBoard(importedBoard, importedTurn);
            moveHistory.Clear();
            appliedMoveCount = 0;
            SelectedMoveIndex = -1;
        }

        var appliedMoves = 0;
        foreach (var moveEntry in parsed.MoveEntries)
        {
            if (!MoveNotationParser.TryParseMoveToken(moveEntry.Token, Board, ActiveTurn, out var move))
            {
                continue;
            }

            var beforeCount = moveHistory.Count;
            TryApplyMove(move, fromEngine: false);
            if (moveHistory.Count > beforeCount)
            {
                if (!string.IsNullOrWhiteSpace(moveEntry.Comment) && moveHistory.Count > 0)
                {
                    moveHistory[^1].Comment = moveEntry.Comment;
                }
                appliedMoves++;
            }
        }

        if (!string.IsNullOrWhiteSpace(parsed.ResultToken))
        {
            Metadata.Result = parsed.ResultToken;
        }

        StatusText = $"PGN imported successfully. Applied moves: {appliedMoves}.";
    }

    public void LoadArchiveFromPgn(string pgnCollection)
    {
        IsArchiveLoading = true;
        archiveLoadStartedUtc = DateTime.UtcNow;
        ArchiveProgressMin = 0;
        ArchiveProgressValue = 0;
        archiveEntries.Clear();
        archiveGames.Clear();
        SelectedArchiveIndex = -1;

        var parsedGames = GameNotationService.ParsePgnCollection(pgnCollection);
        ArchiveProgressMax = parsedGames.Count;
        archiveGames.AddRange(parsedGames);
        for (var index = 0; index < parsedGames.Count; index++)
        {
            var tags = parsedGames[index].Tags;
            archiveEntries.Add(new ArchiveGameSummary
            {
                Index = index,
                Event = tags.GetValueOrDefault("Event", string.Empty),
                Site = tags.GetValueOrDefault("Site", string.Empty),
                Date = tags.GetValueOrDefault("Date", string.Empty),
                Round = tags.GetValueOrDefault("Round", string.Empty),
                White = tags.GetValueOrDefault("White", string.Empty),
                Black = tags.GetValueOrDefault("Black", string.Empty),
                Result = tags.GetValueOrDefault("Result", string.Empty),
                Eco = tags.GetValueOrDefault("ECO", string.Empty)
            });

            ArchiveProgressValue = index + 1;
            ArchiveEstimatedRemainingText = EstimateRemainingArchiveTime();
        }

        IsArchiveLoading = false;
        ArchiveEstimatedRemainingText = "00:00:00";
        StatusText = archiveEntries.Count == 0
            ? "Archive load completed with no games."
            : $"Archive loaded: {archiveEntries.Count} games.";
    }

    public void LoadSelectedArchiveGame()
    {
        if (SelectedArchiveIndex < 0 || SelectedArchiveIndex >= archiveGames.Count)
        {
            StatusText = "No archive game selected.";
            return;
        }

        var selected = archiveGames[SelectedArchiveIndex];
        if (string.IsNullOrWhiteSpace(selected.RawText))
        {
            StatusText = "Selected archive game cannot be loaded.";
            return;
        }

        ImportPgnText(selected.RawText);
        StatusText = $"Archive game {SelectedArchiveIndex + 1} loaded.";
    }

    public void SelectArchiveRow(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= archiveEntries.Count)
        {
            SelectedArchiveIndex = -1;
            return;
        }

        SelectedArchiveIndex = rowIndex;
        StatusText = $"Selected archive row {rowIndex + 1}.";
    }

    public void SearchArchiveNext()
    {
        var search = ArchiveSearchText?.Trim();
        if (string.IsNullOrWhiteSpace(search) || archiveEntries.Count == 0)
        {
            return;
        }

        var words = search.ToUpperInvariant()
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (words.Length == 0)
        {
            return;
        }

        var start = SelectedArchiveIndex + 1;
        if (start >= archiveEntries.Count || start < 0)
        {
            start = 0;
        }

        var cursor = start;
        do
        {
            var row = archiveEntries[cursor];
            var found = words.All(word => row.SearchBlob.Contains(word, StringComparison.Ordinal));
            if (found)
            {
                SelectedArchiveIndex = cursor;
                StatusText = $"Archive search matched row {cursor + 1}.";
                return;
            }

            cursor++;
            if (cursor >= archiveEntries.Count)
            {
                cursor = 0;
            }
        } while (cursor != start);

        StatusText = "Archive search reached end with no match.";
    }

    public void GoToPreviousMove()
    {
        GoToMove(currentPly - 1);
    }

    public void GoToNextMove()
    {
        GoToMove(currentPly + 1);
    }

    public void GoToMove(int ply)
    {
        if (moveHistory.Count == 0)
        {
            StatusText = "No moves available in history.";
            return;
        }

        var targetPly = Math.Clamp(ply, 0, moveHistory.Count);
        RestoreInitialPosition();

        for (var index = 0; index < targetPly; index++)
        {
            if (EngineMoveParser.TryParseMoveToken(moveHistory[index].Notation, out var move))
            {
                ApplyMoveOnBoardOnly(move);
            }
        }

        currentPly = targetPly;
        SelectedMoveIndex = targetPly - 1;
        StatusText = $"Showing move position {targetPly}/{moveHistory.Count}.";
    }

    public void Undo()
    {
        StatusText = "Undo command mapped. Legacy board-state undo is not yet wired.";
    }

    public void Redo()
    {
        StatusText = "Redo command mapped. Legacy board-state redo is not yet wired.";
    }

    public void SelectMove(int moveIndex)
    {
        if (moveIndex < 0 || moveIndex >= moveHistory.Count)
        {
            SelectedMoveIndex = -1;
            return;
        }

        SelectedMoveIndex = moveIndex;
        StatusText = $"Selected move {moveHistory[moveIndex].PlyNumber}.";
    }

    public void UpdateSelectedMoveComment(string comment)
    {
        if (SelectedMoveIndex < 0 || SelectedMoveIndex >= moveHistory.Count)
        {
            return;
        }

        moveHistory[SelectedMoveIndex].Comment = comment;
        StatusText = $"Updated comment for move {moveHistory[SelectedMoveIndex].PlyNumber}.";
    }

    public void MarkActionMapped(string action)
    {
        StatusText = $"{action} is mapped and ready for logic porting.";
    }

    public void ConfigureTimeControl(int reflectionMinutes, int movesPerTimeControl, int bonusSecondsPerMove)
    {
        ReflectionMinutes = Math.Max(0, reflectionMinutes);
        MovesPerTimeControl = Math.Max(0, movesPerTimeControl);
        BonusSecondsPerMove = Math.Max(0, bonusSecondsPerMove);
        WhiteTimeExpired = false;
        BlackTimeExpired = false;
        StatusText = "Time control updated.";
    }

    public void ChangePieceSet(string pieceSet)
    {
        if (string.IsNullOrWhiteSpace(pieceSet))
        {
            return;
        }

        if (!PieceSetOptions.Contains(pieceSet, StringComparer.Ordinal))
        {
            return;
        }

        SelectedPieceSet = pieceSet;
        StatusText = $"Piece set selected: {pieceSet}.";
    }

    public void RunExtraMergeArchiveOperation()
    {
        LastExtraOperation = "Merge all games into a unique archive";
        var result = LegacyArchiveToolsService.MergeAllArchivesIntoUniqueArchive(LegacyApplicationRootPath);
        StatusText = result.Message;
    }

    public void RunExtraBuildSituationArchiveOperation()
    {
        LastExtraOperation = "Build game situations archive";
        var result = LegacyArchiveToolsService.BuildGameSituationArchive(LegacyApplicationRootPath);
        StatusText = result.Message;
    }

    public void ClearBoard()
    {
        Array.Clear(Board);
        selectedSquare = null;
        StatusText = "Board cleared.";
    }

    public void AnalyzeCurrentPosition()
    {
        EngineOutput = "Analyzing position...";
        AppendEngineThought("Engine: starting position analysis.");
        StatusText = "Engine analysis requested.";
    }

    public void RequestEngineMoveComputation()
    {
        if (!IsEngineAvailable)
        {
            StatusText = "No engine executable available in Motori folder.";
            return;
        }

        if (IsEngineComputationRunning)
        {
            return;
        }

        IsEngineComputationRunning = true;
        EngineOutput = "Waiting for engine move...";
        AppendEngineThought("Engine move computation started.");
        StatusText = "Engine move computation in progress.";
    }

    public void RefreshEngineBinding()
    {
        var enginesFolder = Path.Combine(LegacyApplicationRootPath, "Motori");
        if (!Directory.Exists(enginesFolder))
        {
            EngineBinaryPath = string.Empty;
            return;
        }

        EngineBinaryPath = Directory
            .EnumerateFiles(enginesFolder, "*.exe", SearchOption.TopDirectoryOnly)
            .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault() ?? string.Empty;
    }

    public void StopEngineMoveComputation(bool updateStatus = true)
    {
        IsEngineComputationRunning = false;
        if (updateStatus)
        {
            StatusText = IsGameFinished
                ? $"Game has concluded: {GameFinishedReason}."
                : "Engine move computation stopped.";
        }
    }

    public void ApplyEngineLine(string line)
    {
        if (!EngineMoveParser.TryParseEngineLine(line, out var move))
        {
            EngineOutput = $"Invalid engine line: {line}";
            AppendEngineThought($"Engine output rejected: {line}");
            StatusText = "Engine line could not be parsed.";
            return;
        }

        StopEngineMoveComputation(updateStatus: false);
        AppendEngineThought($"Engine output: {line}");
        TryApplyMove(move, fromEngine: true);
    }

    public void TickClock()
    {
        if (ReflectionMinutes == 0 && BonusSecondsPerMove == 0)
        {
            return;
        }

        if (!WhiteTimeExpired && GetRemainingTime(PieceColor.White) < TimeSpan.Zero)
        {
            WhiteTimeExpired = true;
            StatusText = "White reflection time expired.";
            MarkGameFinished("Time expired for White");
        }

        if (!BlackTimeExpired && GetRemainingTime(PieceColor.Black) < TimeSpan.Zero)
        {
            BlackTimeExpired = true;
            StatusText = "Black reflection time expired.";
            MarkGameFinished("Time expired for Black");
        }
    }

    public void SelectOrMove(BoardPosition position)
    {
        if (!IsBoardInteractionEnabled)
        {
            StatusText = IsGameFinished
                ? $"Game is finished: {GameFinishedReason}."
                : "Select the promoted piece.";
            return;
        }

        var piece = Board[position.File, position.Rank];

        if (selectedSquare is null)
        {
            if (piece.Type == PieceType.None)
            {
                StatusText = "Select a piece first.";
                return;
            }

            selectedSquare = position;
            StatusText = $"Selected {piece.Color} {piece.Type} on {position}.";
            return;
        }

        var from = selectedSquare.Value;
        selectedSquare = null;

        if (from.Equals(position))
        {
            StatusText = "Selection cleared.";
            return;
        }

        var sourcePiece = Board[from.File, from.Rank];
        if (sourcePiece.Type == PieceType.Pawn)
        {
            var reachedLastRank = (sourcePiece.Color == PieceColor.White && position.Rank == 7)
                || (sourcePiece.Color == PieceColor.Black && position.Rank == 0);
            if (reachedLastRank)
            {
                pendingPromotionMove = new ChessMove(from, position);
                IsAwaitingPromotionSelection = true;
                StatusText = "Select the promoted piece.";
                return;
            }
        }

        var move = new ChessMove(from, position);
        TryApplyMove(move, fromEngine: false);
    }

    public void CompletePromotionSelection(PieceType promotedPiece)
    {
        if (!IsAwaitingPromotionSelection || pendingPromotionMove is null)
        {
            return;
        }

        var effectivePromotion = promotedPiece is PieceType.Queen or PieceType.Rook or PieceType.Bishop or PieceType.Knight
            ? promotedPiece
            : PieceType.Queen;

        var move = new ChessMove(
            pendingPromotionMove.Value.From,
            pendingPromotionMove.Value.To,
            effectivePromotion);

        IsAwaitingPromotionSelection = false;
        pendingPromotionMove = null;
        TryApplyMove(move, fromEngine: false);
    }

    public void MarkGameFinished(string reason)
    {
        if (IsGameFinished)
        {
            return;
        }

        StopEngineMoveComputation(updateStatus: false);
        IsGameFinished = true;
        GameFinishedReason = string.IsNullOrWhiteSpace(reason) ? "Game concluded" : reason.Trim();
        IsAwaitingPromotionSelection = false;
        pendingPromotionMove = null;
        StatusText = $"Game has concluded: {GameFinishedReason}.";
    }

    public void ToggleBoardCoordinates()
    {
        ShowBoardCoordinates = !ShowBoardCoordinates;
        StatusText = ShowBoardCoordinates
            ? "Board coordinates enabled."
            : "Board coordinates disabled.";
    }

    public void ToggleBorderSelection()
    {
        UseBorderSelection = !UseBorderSelection;
        StatusText = UseBorderSelection
            ? "Border selection enabled."
            : "Border selection disabled.";
    }

    public void ToggleSurfaceHighlight()
    {
        UseSurfaceHighlight = !UseSurfaceHighlight;
        StatusText = UseSurfaceHighlight
            ? "Surface highlight enabled."
            : "Surface highlight disabled.";
    }

    public void ForceTurn(PieceColor side)
    {
        ActiveTurn = side;
        activeTurnStartedUtc = DateTime.UtcNow;
        SelectedEditabilityIndex = side == PieceColor.White ? 2 : 3;
        StatusText = side == PieceColor.White
            ? "Turn set to White."
            : "Turn set to Black.";
    }

    public void SetEditability(int index)
    {
        var normalized = Math.Clamp(index, 0, EditabilityOptions.Count - 1);
        SelectedEditabilityIndex = normalized;

        switch (normalized)
        {
            case 0:
                StatusText = "Board locked.";
                break;
            case 1:
                StatusText = "Board edit mode enabled.";
                break;
            case 2:
                ActiveTurn = PieceColor.White;
                activeTurnStartedUtc = DateTime.UtcNow;
                StatusText = "White to move mode enabled.";
                break;
            case 3:
                ActiveTurn = PieceColor.Black;
                activeTurnStartedUtc = DateTime.UtcNow;
                StatusText = "Black to move mode enabled.";
                break;
        }
    }

    public void ToggleEditabilityMode()
    {
        SetEditability(SelectedEditabilityIndex == 1 ? 0 : 1);
    }

    public void LockBoard()
    {
        SetEditability(0);
    }

    public void SetStandardInitialPosition()
    {
        Array.Clear(Board);
        PlaceBackRank(0, PieceColor.White);
        PlacePawns(1, PieceColor.White);
        PlacePawns(6, PieceColor.Black);
        PlaceBackRank(7, PieceColor.Black);

        selectedSquare = null;
        moveHistory.Clear();
        appliedMoveCount = 0;
        currentPly = 0;
        SelectedMoveIndex = -1;
        ActiveTurn = PieceColor.White;
        activeTurnStartedUtc = DateTime.UtcNow;
        IsAwaitingPromotionSelection = false;
        pendingPromotionMove = null;
        IsGameFinished = false;
        GameFinishedReason = string.Empty;

        CaptureInitialPosition();
        SetEditability(0);
        StatusText = "Initial board position restored.";
    }

    public void SetWhitePlayerController(bool computer)
    {
        Metadata.WhitePlayer.PlayerType = computer ? "Computer" : "Human";
        StatusText = computer
            ? "White player set to Computer."
            : "White player set to Human.";
    }

    public void SetBlackPlayerController(bool computer)
    {
        Metadata.BlackPlayer.PlayerType = computer ? "Computer" : "Human";
        StatusText = computer
            ? "Black player set to Computer."
            : "Black player set to Human.";
    }

    public void CopyBoardState()
    {
        clipboardBoard = CloneBoard(Board);
        clipboardTurn = ActiveTurn;
        StatusText = "Board state copied.";
    }

    public void CutBoardState()
    {
        CopyBoardState();
        ClearBoard();
        SetEditability(1);
        StatusText = "Board state cut.";
    }

    public void PasteBoardState()
    {
        if (clipboardBoard is null)
        {
            StatusText = "Clipboard is empty.";
            return;
        }

        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                Board[file, rank] = clipboardBoard[file, rank];
            }
        }

        ActiveTurn = clipboardTurn;
        activeTurnStartedUtc = DateTime.UtcNow;
        selectedSquare = null;
        IsAwaitingPromotionSelection = false;
        pendingPromotionMove = null;
        IsGameFinished = false;
        GameFinishedReason = string.Empty;
        CaptureInitialPosition();
        StatusText = "Board state pasted.";
    }

    public void DuplicateBoardState()
    {
        CopyBoardState();
        StatusText = "Board state duplicated.";
    }

    public void SaveGameAsMapped()
    {
        StatusText = "Save as mapped to export workflow.";
    }

    public void ExitApplicationMapped()
    {
        StatusText = "Exit command mapped.";
    }

    public void ArrangeWindowsMapped(string arrangement)
    {
        StatusText = arrangement + " arrangement mapped.";
    }

    public void PrintGameMapped()
    {
        StatusText = "Print command mapped.";
    }

    public void AddCommentMapped()
    {
        StatusText = "Comment command mapped.";
    }

    private void TryApplyMove(ChessMove move, bool fromEngine)
    {
        var sourcePiece = Board[move.From.File, move.From.Rank];
        if (sourcePiece.Type == PieceType.None)
        {
            StatusText = $"Invalid move: no piece on {move.From}.";
            return;
        }

        var now = DateTime.UtcNow;
        ConsumeRunningTurnTime(now);

        Board[move.From.File, move.From.Rank] = BoardPiece.Empty;
        var resultingPiece = move.Promotion == PieceType.None
            ? sourcePiece
            : sourcePiece with { Type = move.Promotion };
        Board[move.To.File, move.To.Rank] = resultingPiece;

        var moveText = move.ToString();
        var nextPly = appliedMoveCount + 1;
        moveHistory.Add(new MoveRecord
        {
            PlyNumber = nextPly,
            Notation = moveText
        });
        appliedMoveCount++;
        currentPly = moveHistory.Count;
        SelectedMoveIndex = moveHistory.Count - 1;
        ActiveTurn = ActiveTurn == PieceColor.White ? PieceColor.Black : PieceColor.White;
        activeTurnStartedUtc = now;

        if (fromEngine)
        {
            EngineOutput = $"Engine move applied: {moveText}";
            StatusText = "Engine move applied.";
            return;
        }

        StatusText = $"Move applied: {moveText}.";
    }

    private void AppendEngineThought(string line)
    {
        if (string.IsNullOrWhiteSpace(line))
        {
            return;
        }

        engineThoughtLines.Add(line.Trim());
        if (engineThoughtLines.Count > 200)
        {
            engineThoughtLines.RemoveAt(0);
        }
    }

    private void ConsumeRunningTurnTime(DateTime nowUtc)
    {
        var elapsed = nowUtc - activeTurnStartedUtc;
        if (elapsed < TimeSpan.Zero)
        {
            elapsed = TimeSpan.Zero;
        }

        if (ActiveTurn == PieceColor.White)
        {
            whiteElapsed += elapsed;
        }
        else if (ActiveTurn == PieceColor.Black)
        {
            blackElapsed += elapsed;
        }
    }

    private TimeSpan GetRemainingTime(PieceColor side)
    {
        var elapsed = side == PieceColor.White ? whiteElapsed : blackElapsed;
        if (ActiveTurn == side)
        {
            elapsed += DateTime.UtcNow - activeTurnStartedUtc;
        }

        var available = TimeSpan.FromSeconds(GetAvailableSecondsForSide(side));
        return available - elapsed;
    }

    private long GetAvailableSecondsForSide(PieceColor side)
    {
        var baseSeconds = ReflectionMinutes * 60L;
        var sideMoves = GetCompletedMovesForSide(side);

        if (MovesPerTimeControl > 0)
        {
            baseSeconds *= 1 + ((Math.Max(1, sideMoves) - 1) / MovesPerTimeControl);
        }

        if (BonusSecondsPerMove > 0)
        {
            baseSeconds += BonusSecondsPerMove * sideMoves;
        }

        return baseSeconds;
    }

    private int GetCompletedMovesForSide(PieceColor side)
    {
        return side switch
        {
            PieceColor.White => (appliedMoveCount + 1) / 2,
            PieceColor.Black => appliedMoveCount / 2,
            _ => 0
        };
    }

    private static string FormatClock(TimeSpan value)
    {
        var positive = value >= TimeSpan.Zero;
        var absolute = positive ? value : value.Negate();
        var hours = (int)absolute.TotalHours;
        var text = $"{hours:00}:{absolute.Minutes:00}:{absolute.Seconds:00}";
        return positive ? text : $"-{text}";
    }

    private int GetCurrentFullMoveNumber()
    {
        return Math.Max(1, (appliedMoveCount + 1) / 2);
    }

    private void LoadBoard(BoardPiece[,] importedBoard, PieceColor importedTurn)
    {
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                Board[file, rank] = importedBoard[file, rank];
            }
        }

        ActiveTurn = importedTurn;
        activeTurnStartedUtc = DateTime.UtcNow;
        whiteElapsed = TimeSpan.Zero;
        blackElapsed = TimeSpan.Zero;
        WhiteTimeExpired = false;
        BlackTimeExpired = false;
    }

    private void ApplyPgnTags(IReadOnlyDictionary<string, string> tags)
    {
        if (tags.TryGetValue("Event", out var eventName)) Metadata.EventNotes = eventName;
        if (tags.TryGetValue("Site", out var site)) Metadata.Location = site;
        if (tags.TryGetValue("Date", out var date)) Metadata.EventDate = date;
        if (tags.TryGetValue("Time", out var time)) Metadata.EventTime = time;
        if (tags.TryGetValue("Round", out var round)) Metadata.Round = round;
        if (tags.TryGetValue("Board", out var boardNumber)) Metadata.BoardNumber = boardNumber;
        if (tags.TryGetValue("Match", out var matchNumber)) Metadata.MatchNumber = matchNumber;
        if (tags.TryGetValue("Result", out var result)) Metadata.Result = NormalizeImportedResult(result);
        if (tags.TryGetValue("ECO", out var eco)) Metadata.EcoCode = eco;
        if (tags.TryGetValue("NIC", out var nic)) Metadata.NicCode = nic;
        if (tags.TryGetValue("Opening", out var opening)) Metadata.Opening = opening;
        if (tags.TryGetValue("Variation", out var variation)) Metadata.SubOpening = variation;
        if (tags.TryGetValue("SubVariation", out var subVariation)) Metadata.Variation = subVariation;
        if (tags.TryGetValue("Annotator", out var annotator)) Metadata.Annotator = annotator;
        if (tags.TryGetValue("EventSponsor", out var sponsor)) Metadata.Sponsor = sponsor;
        if (tags.TryGetValue("Termination", out var termination)) Metadata.Termination = termination;
        if (tags.TryGetValue("Mode", out var mode)) Metadata.PlayMode = NormalizeImportedMode(mode);
        if (tags.TryGetValue("Section", out var session)) Metadata.Session = NormalizeImportedSession(session);
        if (tags.TryGetValue("Stage", out var stage)) Metadata.Round = string.IsNullOrWhiteSpace(Metadata.Round) ? stage : Metadata.Round;
        if (tags.TryGetValue("White", out var whitePlayer)) Metadata.WhitePlayer.Name = whitePlayer;
        if (tags.TryGetValue("Black", out var blackPlayer)) Metadata.BlackPlayer.Name = blackPlayer;
        if (tags.TryGetValue("WhiteElo", out var whiteElo)) Metadata.WhitePlayer.Elo = whiteElo;
        if (tags.TryGetValue("BlackElo", out var blackElo)) Metadata.BlackPlayer.Elo = blackElo;
        if (tags.TryGetValue("WhiteUSCF", out var whiteUscf)) Metadata.WhitePlayer.Uscf = whiteUscf;
        if (tags.TryGetValue("BlackUSCF", out var blackUscf)) Metadata.BlackPlayer.Uscf = blackUscf;
        if (tags.TryGetValue("WhiteTitle", out var whiteTitle)) Metadata.WhitePlayer.Title = whiteTitle;
        if (tags.TryGetValue("BlackTitle", out var blackTitle)) Metadata.BlackPlayer.Title = blackTitle;
        if (tags.TryGetValue("WhiteNA", out var whiteEmail)) Metadata.WhitePlayer.Email = whiteEmail;
        if (tags.TryGetValue("BlackNA", out var blackEmail)) Metadata.BlackPlayer.Email = blackEmail;
        if (tags.TryGetValue("WhiteType", out var whiteType)) Metadata.WhitePlayer.PlayerType = NormalizeImportedPlayerType(whiteType);
        if (tags.TryGetValue("BlackType", out var blackType)) Metadata.BlackPlayer.PlayerType = NormalizeImportedPlayerType(blackType);
        if (tags.TryGetValue("WhiteCountry", out var whiteCountry)) Metadata.WhitePlayer.Country = whiteCountry;
        if (tags.TryGetValue("BlackCountry", out var blackCountry)) Metadata.BlackPlayer.Country = blackCountry;
    }

    private static string NormalizeImportedMode(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "OTB" => "Over the board",
            "PM" => "Postal",
            "EM" => "Email",
            "ICS" => "Internet server",
            "TC" => "Non-standard board",
            _ => value
        };
    }

    private static string NormalizeImportedSession(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "OPEN" => "Open",
            "RESERVE" => "Reserved",
            _ => value
        };
    }

    private static string NormalizeImportedResult(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "1-0" => "White win",
            "0-1" => "Black win",
            "1/2-1/2" => "Draw",
            _ => value
        };
    }

    private static string NormalizeImportedPlayerType(string value)
    {
        return value.Trim().ToUpperInvariant() switch
        {
            "PROGRAM" => "Computer",
            "AUTOMA" => "Automated agent",
            "UNKNOW ENTITY" => "Automated agent",
            _ => value
        };
    }

    private static string ResolveLegacyApplicationRootPath()
    {
        var current = new DirectoryInfo(Environment.CurrentDirectory);
        while (current is not null)
        {
            var siblingLegacyPath = Path.Combine(current.FullName, "Scacchi");
            if (Directory.Exists(siblingLegacyPath))
            {
                return siblingLegacyPath;
            }

            var localLegacyPath = Path.Combine(current.FullName, "Archivio");
            if (Directory.Exists(localLegacyPath))
            {
                return current.FullName;
            }

            current = current.Parent;
        }

        return Environment.CurrentDirectory;
    }

    private AnalysisTreeNode BuildAnalysisTree()
    {
        var root = new AnalysisTreeNode
        {
            Key = "R",
            Label = "Position analysis"
        };

        for (var index = 0; index < moveHistory.Count; index++)
        {
            var move = moveHistory[index];
            var node = new AnalysisTreeNode
            {
                Key = $"M{move.PlyNumber}",
                Label = $"Move {move.PlyNumber}: {move.Notation.ToUpperInvariant()}"
            };

            if (!string.IsNullOrWhiteSpace(move.Comment))
            {
                node.Children.Add(new AnalysisTreeNode
                {
                    Key = $"C{move.PlyNumber}",
                    Label = $"Comment: {move.Comment}"
                });
            }

            root.Children.Add(node);
        }

        return root;
    }

    private string EstimateRemainingArchiveTime()
    {
        if (ArchiveProgressValue <= 0 || ArchiveProgressMax <= ArchiveProgressValue)
        {
            return "00:00:00";
        }

        var elapsed = DateTime.UtcNow - archiveLoadStartedUtc;
        if (elapsed <= TimeSpan.Zero)
        {
            return "00:00:00";
        }

        var averagePerItemTicks = elapsed.Ticks / ArchiveProgressValue;
        var remainingItems = ArchiveProgressMax - ArchiveProgressValue;
        var remaining = TimeSpan.FromTicks(Math.Max(0, averagePerItemTicks * remainingItems));
        return $"{(int)remaining.TotalHours:00}:{remaining.Minutes:00}:{remaining.Seconds:00}";
    }

    private void CaptureInitialPosition()
    {
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                initialBoard[file, rank] = Board[file, rank];
            }
        }

        initialTurn = ActiveTurn;
    }

    private void RestoreInitialPosition()
    {
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                Board[file, rank] = initialBoard[file, rank];
            }
        }

        ActiveTurn = initialTurn;
        activeTurnStartedUtc = DateTime.UtcNow;
    }

    private void ApplyMoveOnBoardOnly(ChessMove move)
    {
        var source = Board[move.From.File, move.From.Rank];
        if (source.IsEmpty)
        {
            return;
        }

        Board[move.From.File, move.From.Rank] = BoardPiece.Empty;
        Board[move.To.File, move.To.Rank] = move.Promotion == PieceType.None
            ? source
            : source with { Type = move.Promotion };
        ActiveTurn = ActiveTurn == PieceColor.White ? PieceColor.Black : PieceColor.White;
    }

    private static BoardPiece[,] CloneBoard(BoardPiece[,] source)
    {
        var clone = new BoardPiece[8, 8];
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                clone[file, rank] = source[file, rank];
            }
        }

        return clone;
    }

    private void PlacePawns(int rank, PieceColor color)
    {
        for (var file = 0; file < 8; file++)
        {
            Board[file, rank] = new BoardPiece(PieceType.Pawn, color);
        }
    }

    private void PlaceBackRank(int rank, PieceColor color)
    {
        Board[0, rank] = new BoardPiece(PieceType.Rook, color);
        Board[1, rank] = new BoardPiece(PieceType.Knight, color);
        Board[2, rank] = new BoardPiece(PieceType.Bishop, color);
        Board[3, rank] = new BoardPiece(PieceType.Queen, color);
        Board[4, rank] = new BoardPiece(PieceType.King, color);
        Board[5, rank] = new BoardPiece(PieceType.Bishop, color);
        Board[6, rank] = new BoardPiece(PieceType.Knight, color);
        Board[7, rank] = new BoardPiece(PieceType.Rook, color);
    }
}