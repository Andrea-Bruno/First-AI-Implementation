using System.Text;
using Chess.Shared.Engine;

namespace Chess.Shared.Application;

public sealed class LegacyArchiveOperationResult
{
    public bool Succeeded { get; init; }
    public string Message { get; init; } = string.Empty;
    public int ProcessedFiles { get; init; }
    public int ProcessedGames { get; init; }
    public int AddedGames { get; init; }
    public int DuplicatedGames { get; init; }
    public int SituationEntries { get; init; }
    public string ArchiveFolderPath { get; init; } = string.Empty;
}

public static class LegacyArchiveToolsService
{
    public static LegacyArchiveOperationResult MergeAllArchivesIntoUniqueArchive(string applicationRootPath)
    {
        var archiveFolder = Path.Combine(applicationRootPath, "Archivio");
        Directory.CreateDirectory(archiveFolder);

        var stagingPgnFolder = Path.Combine(archiveFolder, "PGN");
        var stagingErrorFolder = Path.Combine(archiveFolder, "ERROR");
        Directory.CreateDirectory(stagingPgnFolder);
        Directory.CreateDirectory(stagingErrorFolder);

        var archivePgnPath = Path.Combine(archiveFolder, "archivio.pgn");
        var univocalPath = Path.Combine(archiveFolder, "Univoco.tmp");

        var uniqueCodes = new HashSet<string>(StringComparer.Ordinal);
        var existingArchiveText = File.Exists(archivePgnPath)
            ? File.ReadAllText(archivePgnPath)
            : string.Empty;

        if (!string.IsNullOrWhiteSpace(existingArchiveText))
        {
            foreach (var game in GameNotationService.ParsePgnCollection(existingArchiveText))
            {
                uniqueCodes.Add(BuildUnivocalCode(game));
            }
        }

        if (File.Exists(univocalPath))
        {
            foreach (var line in File.ReadAllLines(univocalPath))
            {
                var code = line.Trim();
                if (!string.IsNullOrWhiteSpace(code))
                {
                    uniqueCodes.Add(code);
                }
            }
        }

        var sourceFiles = Directory
            .EnumerateFiles(archiveFolder, "*.pgn", SearchOption.TopDirectoryOnly)
            .Where(path => !string.Equals(Path.GetFileName(path), "archivio.pgn", StringComparison.OrdinalIgnoreCase))
            .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var mergedGames = new List<string>();
        var reportLines = new List<string>();

        var processedFiles = 0;
        var processedGames = 0;
        var addedGames = 0;
        var duplicatedGames = 0;

        foreach (var filePath in sourceFiles)
        {
            processedFiles++;
            var parseSucceeded = true;

            try
            {
                NormalizeLineEndingsWhenMissingCarriageReturn(filePath);

                var fileText = File.ReadAllText(filePath);
                var games = GameNotationService.ParsePgnCollection(fileText);
                if (games.Count == 0)
                {
                    parseSucceeded = false;
                }
                else
                {
                    foreach (var game in games)
                    {
                        processedGames++;
                        var code = BuildUnivocalCode(game);
                        if (uniqueCodes.Contains(code))
                        {
                            duplicatedGames++;
                            continue;
                        }

                        uniqueCodes.Add(code);
                        mergedGames.Add(NormalizePgnChunk(game.RawText));
                        addedGames++;
                    }
                }
            }
            catch (Exception exception)
            {
                parseSucceeded = false;
                reportLines.Add($"Error in file {Path.GetFileName(filePath)}: {exception.Message}");
            }

            MoveFileReplacingTarget(filePath, parseSucceeded ? stagingPgnFolder : stagingErrorFolder);
            if (!parseSucceeded)
            {
                reportLines.Add($"Parse failure in file {Path.GetFileName(filePath)}.");
            }
        }

        if (mergedGames.Count > 0)
        {
            using var writer = new StreamWriter(archivePgnPath, append: File.Exists(archivePgnPath), Encoding.UTF8);
            foreach (var game in mergedGames)
            {
                writer.WriteLine(game);
                writer.WriteLine();
            }
        }

        File.WriteAllLines(univocalPath, uniqueCodes.OrderBy(code => code, StringComparer.Ordinal));

        if (reportLines.Count > 0)
        {
            var reportPath = Path.Combine(archiveFolder, "Rapporto.txt");
            File.AppendAllLines(reportPath, reportLines);
        }

        return new LegacyArchiveOperationResult
        {
            Succeeded = true,
            ProcessedFiles = processedFiles,
            ProcessedGames = processedGames,
            AddedGames = addedGames,
            DuplicatedGames = duplicatedGames,
            ArchiveFolderPath = archiveFolder,
            Message = $"Merge completed. Files: {processedFiles}, games: {processedGames}, added: {addedGames}, duplicates: {duplicatedGames}."
        };
    }

    public static LegacyArchiveOperationResult BuildGameSituationArchive(string applicationRootPath)
    {
        var archiveFolder = Path.Combine(applicationRootPath, "Archivio");
        Directory.CreateDirectory(archiveFolder);

        var archivePgnPath = Path.Combine(archiveFolder, "archivio.pgn");
        if (!File.Exists(archivePgnPath))
        {
            return new LegacyArchiveOperationResult
            {
                Succeeded = false,
                ArchiveFolderPath = archiveFolder,
                Message = "Missing archive file: archivio.pgn."
            };
        }

        var allGames = GameNotationService.ParsePgnCollection(File.ReadAllText(archivePgnPath));
        if (allGames.Count == 0)
        {
            return new LegacyArchiveOperationResult
            {
                Succeeded = false,
                ArchiveFolderPath = archiveFolder,
                Message = "Archive file does not contain games."
            };
        }

        var progressPath = Path.Combine(archiveFolder, "Situazione.Pos");
        var startGameIndex = 0;
        var startPlyIndex = -1;
        if (File.Exists(progressPath))
        {
            var progressText = File.ReadAllText(progressPath).Trim();
            var parts = progressText.Split(';', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 2 && int.TryParse(parts[0], out var gameIndex) && int.TryParse(parts[1], out var plyIndex))
            {
                startGameIndex = Math.Clamp(gameIndex, 0, allGames.Count - 1);
                startPlyIndex = Math.Max(-1, plyIndex);
            }
        }

        var situationMap = new Dictionary<string, SituationStats>(StringComparer.Ordinal);
        var processedGames = 0;
        var situationEntries = 0;

        for (var gameIndex = startGameIndex; gameIndex < allGames.Count; gameIndex++)
        {
            var game = allGames[gameIndex];
            var resultToken = game.ResultToken;
            if (string.IsNullOrWhiteSpace(resultToken) && game.Tags.TryGetValue("Result", out var tagResult))
            {
                resultToken = tagResult;
            }

            var board = new BoardPiece[8, 8];
            var turn = PieceColor.White;
            if (game.Tags.TryGetValue("FEN", out var fenTag) && GameNotationService.TryImportFen(fenTag, out var fenBoard, out var fenTurn))
            {
                board = CloneBoard(fenBoard);
                turn = fenTurn;
            }
            else
            {
                SetupInitialBoard(board);
            }

            var gameStates = new List<string>();
            gameStates.Add(BuildSituationKey(board, turn));

            foreach (var entry in game.MoveEntries)
            {
                if (!MoveNotationParser.TryParseMoveToken(entry.Token, board, turn, out var move))
                {
                    continue;
                }

                ApplyMove(board, move);
                turn = turn == PieceColor.White ? PieceColor.Black : PieceColor.White;
                gameStates.Add(BuildSituationKey(board, turn));
            }

            var startStateIndex = gameStates.Count - 1;
            if (gameIndex == startGameIndex && startPlyIndex >= 0)
            {
                startStateIndex = Math.Min(startStateIndex, startPlyIndex);
            }

            for (var stateIndex = startStateIndex; stateIndex >= 0; stateIndex--)
            {
                var key = gameStates[stateIndex];
                if (!situationMap.TryGetValue(key, out var stats))
                {
                    stats = new SituationStats();
                    situationMap[key] = stats;
                }

                stats.RegisterResult(resultToken, gameIndex);
                situationEntries++;
                File.WriteAllText(progressPath, $"{gameIndex};{stateIndex}");
            }

            startPlyIndex = -1;
            processedGames++;
        }

        var sitPath = Path.Combine(archiveFolder, "Archivio.Sit");
        var ordPath = Path.Combine(archiveFolder, "Archivio.ord");

        var sitLines = situationMap
            .OrderBy(pair => pair.Key, StringComparer.Ordinal)
            .Select(pair => $"{pair.Key}|{pair.Value.WhiteWins}|{pair.Value.Draws}|{pair.Value.BlackWins}|{string.Join(',', pair.Value.GameIndexes)}")
            .ToList();

        File.WriteAllLines(sitPath, sitLines);
        File.WriteAllLines(ordPath, sitLines.Select(line => line.Split('|')[0]));
        File.WriteAllText(progressPath, "0;-1");

        return new LegacyArchiveOperationResult
        {
            Succeeded = true,
            ProcessedGames = processedGames,
            SituationEntries = situationEntries,
            ArchiveFolderPath = archiveFolder,
            Message = $"Situation archive completed. Games: {processedGames}, situation entries: {situationEntries}, unique situations: {situationMap.Count}."
        };
    }

    private static void NormalizeLineEndingsWhenMissingCarriageReturn(string filePath)
    {
        var bytes = File.ReadAllBytes(filePath);
        var probeLength = Math.Min(bytes.Length, 100);
        var hasCarriageReturn = false;
        for (var index = 0; index < probeLength; index++)
        {
            if (bytes[index] == '\r')
            {
                hasCarriageReturn = true;
                break;
            }
        }

        if (hasCarriageReturn)
        {
            return;
        }

        var text = File.ReadAllText(filePath);
        var normalized = text.Replace("\r\n", "\n").Replace("\n", "\r\n");
        File.WriteAllText(filePath, normalized);
    }

    private static string BuildUnivocalCode(ImportedPgn game)
    {
        var year = "0000";
        if (game.Tags.TryGetValue("Date", out var date))
        {
            var digits = new string(date.Where(char.IsDigit).ToArray());
            if (digits.Length >= 4)
            {
                year = digits[..4];
            }
        }

        var board = new BoardPiece[8, 8];
        var turn = PieceColor.White;
        if (game.Tags.TryGetValue("FEN", out var fenTag) && GameNotationService.TryImportFen(fenTag, out var fenBoard, out var fenTurn))
        {
            board = CloneBoard(fenBoard);
            turn = fenTurn;
        }
        else
        {
            SetupInitialBoard(board);
        }

        foreach (var moveEntry in game.MoveEntries)
        {
            if (!MoveNotationParser.TryParseMoveToken(moveEntry.Token, board, turn, out var move))
            {
                continue;
            }

            ApplyMove(board, move);
            turn = turn == PieceColor.White ? PieceColor.Black : PieceColor.White;
        }

        var fen = GameNotationService.ExportFen(board, turn, 1);
        return year + "|" + fen;
    }

    private static string BuildSituationKey(BoardPiece[,] board, PieceColor turn)
    {
        return GameNotationService.ExportFen(board, turn, 1);
    }

    private static BoardPiece[,] CloneBoard(BoardPiece[,] source)
    {
        var target = new BoardPiece[8, 8];
        for (var file = 0; file < 8; file++)
        {
            for (var rank = 0; rank < 8; rank++)
            {
                target[file, rank] = source[file, rank];
            }
        }

        return target;
    }

    private static void ApplyMove(BoardPiece[,] board, ChessMove move)
    {
        var piece = board[move.From.File, move.From.Rank];
        board[move.From.File, move.From.Rank] = BoardPiece.Empty;
        board[move.To.File, move.To.Rank] = move.Promotion == PieceType.None
            ? piece
            : piece with { Type = move.Promotion };
    }

    private static string NormalizePgnChunk(string rawText)
    {
        return (rawText ?? string.Empty).Trim();
    }

    private static void MoveFileReplacingTarget(string sourceFilePath, string destinationFolder)
    {
        var destinationPath = Path.Combine(destinationFolder, Path.GetFileName(sourceFilePath));
        if (File.Exists(destinationPath))
        {
            File.Delete(destinationPath);
        }

        File.Copy(sourceFilePath, destinationPath);
        File.Delete(sourceFilePath);
    }

    private static void SetupInitialBoard(BoardPiece[,] board)
    {
        Array.Clear(board);
        PlaceBackRank(board, 0, PieceColor.White);
        PlacePawns(board, 1, PieceColor.White);
        PlacePawns(board, 6, PieceColor.Black);
        PlaceBackRank(board, 7, PieceColor.Black);
    }

    private static void PlacePawns(BoardPiece[,] board, int rank, PieceColor color)
    {
        for (var file = 0; file < 8; file++)
        {
            board[file, rank] = new BoardPiece(PieceType.Pawn, color);
        }
    }

    private static void PlaceBackRank(BoardPiece[,] board, int rank, PieceColor color)
    {
        board[0, rank] = new BoardPiece(PieceType.Rook, color);
        board[1, rank] = new BoardPiece(PieceType.Knight, color);
        board[2, rank] = new BoardPiece(PieceType.Bishop, color);
        board[3, rank] = new BoardPiece(PieceType.Queen, color);
        board[4, rank] = new BoardPiece(PieceType.King, color);
        board[5, rank] = new BoardPiece(PieceType.Bishop, color);
        board[6, rank] = new BoardPiece(PieceType.Knight, color);
        board[7, rank] = new BoardPiece(PieceType.Rook, color);
    }

    private sealed class SituationStats
    {
        public int WhiteWins { get; private set; }
        public int Draws { get; private set; }
        public int BlackWins { get; private set; }
        public HashSet<int> GameIndexes { get; } = [];

        public void RegisterResult(string resultToken, int gameIndex)
        {
            switch (resultToken?.Trim())
            {
                case "1-0":
                    WhiteWins++;
                    break;
                case "0-1":
                    BlackWins++;
                    break;
                case "1/2-1/2":
                    Draws++;
                    break;
            }

            GameIndexes.Add(gameIndex);
        }
    }
}
