namespace Chess.Shared.Application;

public sealed class MoveRecord
{
    public required int PlyNumber { get; init; }

    public required string Notation { get; init; }

    public string Comment { get; set; } = string.Empty;
}

public sealed class PlayerMetadata
{
    public string Name { get; set; } = string.Empty;
    public string Elo { get; set; } = string.Empty;
    public string Uscf { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string PlayerType { get; set; } = "Human";
    public string Email { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;

    public void Reset()
    {
        Name = string.Empty;
        Elo = string.Empty;
        Uscf = string.Empty;
        Title = string.Empty;
        PlayerType = "Human";
        Email = string.Empty;
        Country = string.Empty;
    }
}

public sealed class GameMetadata
{
    public string EventNotes { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public string EventDate { get; set; } = string.Empty;
    public string EventTime { get; set; } = string.Empty;
    public string Sponsor { get; set; } = string.Empty;
    public string Session { get; set; } = string.Empty;
    public string Round { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public string BoardNumber { get; set; } = string.Empty;
    public string MatchNumber { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string Opening { get; set; } = string.Empty;
    public string SubOpening { get; set; } = string.Empty;
    public string Variation { get; set; } = string.Empty;
    public string EcoCode { get; set; } = string.Empty;
    public string NicCode { get; set; } = string.Empty;
    public string Termination { get; set; } = string.Empty;
    public string Annotator { get; set; } = string.Empty;
    public string ExtraInfo { get; set; } = string.Empty;
    public string PlayMode { get; set; } = string.Empty;

    public PlayerMetadata WhitePlayer { get; } = new();
    public PlayerMetadata BlackPlayer { get; } = new();

    public IReadOnlyList<string> SessionOptions { get; } = ["", "Open", "Reserved"];
    public IReadOnlyList<string> EventTypeOptions { get; } = ["", "Standard", "Blitz", "Rapid"];
    public IReadOnlyList<string> RoundOptions { get; } = ["", "Final", "Semifinal", "Quarterfinal", "Round of 16", "Qualification"];
    public IReadOnlyList<string> ResultOptions { get; } = ["", "White win", "Black win", "Draw", "1-0", "0-1", "1/2-1/2"];
    public IReadOnlyList<string> TerminationOptions { get; } = ["", "Normal", "Suspended", "Abandoned", "Adjudicated", "Time expired", "Emergency", "Agreed"];
    public IReadOnlyList<string> PlayModeOptions { get; } = ["", "Standard board", "Postal", "Email", "Internet server", "Communication medium", "Blindfold", "Non-standard board", "Hologram"];
    public IReadOnlyList<string> PlayerTypeOptions { get; } = ["Human", "Computer", "Robot", "Automated agent", "Cybernetic", "Droid", "Mutant", "Clone", "Alien", "Animal", "Unknown entity"];
    public IReadOnlyList<string> TitleOptions { get; } = ["", "FM", "IM", "GM"];

    public void Reset()
    {
        EventNotes = string.Empty;
        Location = string.Empty;
        EventDate = string.Empty;
        EventTime = string.Empty;
        Sponsor = string.Empty;
        Session = string.Empty;
        Round = string.Empty;
        EventType = string.Empty;
        BoardNumber = string.Empty;
        MatchNumber = string.Empty;
        Result = string.Empty;
        Opening = string.Empty;
        SubOpening = string.Empty;
        Variation = string.Empty;
        EcoCode = string.Empty;
        NicCode = string.Empty;
        Termination = string.Empty;
        Annotator = string.Empty;
        ExtraInfo = string.Empty;
        PlayMode = string.Empty;
        WhitePlayer.Reset();
        BlackPlayer.Reset();
    }
}

public sealed class ArchiveGameSummary
{
    public int Index { get; init; }
    public string Event { get; init; } = string.Empty;
    public string Site { get; init; } = string.Empty;
    public string Date { get; init; } = string.Empty;
    public string Round { get; init; } = string.Empty;
    public string White { get; init; } = string.Empty;
    public string Black { get; init; } = string.Empty;
    public string Result { get; init; } = string.Empty;
    public string Eco { get; init; } = string.Empty;

    public string SearchBlob =>
        $"{Event} {Site} {Date} {Round} {White} {Black} {Result} {Eco}".ToUpperInvariant();
}

public sealed class AnalysisTreeNode
{
    public string Key { get; init; } = string.Empty;
    public string Label { get; init; } = string.Empty;
    public List<AnalysisTreeNode> Children { get; } = [];
}