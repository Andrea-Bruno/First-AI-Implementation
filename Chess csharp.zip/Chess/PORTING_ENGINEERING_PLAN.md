# VB6 to C# Porting Engineering Plan

## Scope

- Source legacy application: `Scacchi` (VB6 with OCX-based UI).
- Target application: `Chess` (C# with Blazor UI in MAUI/Web).
- Porting policy: all new and migrated identifiers, comments, and UI text must be in English.

## Migration Principles

1. Preserve functional behavior before optimization.
2. Replace OCX controls with Blazor components, not wrappers around COM.
3. Separate responsibilities:
   - `Chess.Shared.Engine`: chess domain primitives and move logic.
   - `Chess.Shared.Application`: orchestration and application state.
   - `Chess.Shared.Pages` and `Chess.Shared.Components`: Blazor UI.
4. Keep each migration slice buildable and testable.
5. Do not introduce new gameplay rules or heuristic logic; port only proven legacy behavior.

## Legacy UI to Blazor Mapping

- `MDIScacchi` (main MDI form) → `MainWindow.razor` root page.
- `ControlloScacchiera.Scacchiera` OCX → `ChessBoard.razor` component.
- Toolbar buttons and menu entries → Blazor button commands grouped by feature.
- Auxiliary forms (`Orologio`, `Pensiero`, `ElencoMosse`, `Nota`) → dedicated Razor pages/components.

## Incremental Delivery Slices

1. Shell and navigation parity:
   - Main window commands and game status panel.
2. Board interaction parity:
   - Selection, move application, history list.
3. Engine interaction parity:
   - Engine output parsing and asynchronous state refresh.
4. Metadata and notation parity:
   - Event data, player details, PGN/FEN I/O.
   - SAN and coordinate PGN move import with legacy tag mapping.
5. Advanced tooling parity:
   - Analysis, clock behavior, archived positions.

## Acceptance Criteria per Slice

- Build passes for `Chess.sln`.
- New code uses English naming only.
- Legacy feature map updated with implemented coverage.
- No VB6/OCX runtime dependency added to target application.
