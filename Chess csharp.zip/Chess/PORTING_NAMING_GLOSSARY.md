# Porting Naming Glossary (Italian to English)

This glossary defines mandatory translations for identifiers and UI labels while porting from VB6.

## Core Application Terms

- `Scacchi` → `Chess`
- `Gioco` → `Game`
- `Scacchiera` → `Board`
- `Mossa` / `Mosse` → `Move` / `Moves`
- `Traccia` → `MoveHistory`
- `Editabilita` → `EditMode`
- `Aggiungi` → `Add`
- `Elimina` → `Remove`
- `Apri` → `Open`
- `Salva` → `Save`
- `Nuovo` → `New`
- `Chiudi` → `Close`
- `Avanti` → `Redo` or `Next`
- `Indietro` → `Undo` or `Previous`

## Metadata Terms

- `Annotatore` → `Annotator`
- `Apertura` → `Opening`
- `SottoApertura` → `SubOpening`
- `Luogo` → `Location`
- `Incontro` → `Match`
- `Turno` → `Round`
- `Nazione` → `Country`
- `Titolo` → `Title`
- `Sponsor` → `Sponsor`
- `Terminato` → `Termination`

## Player and Side Terms

- `Bianco` → `White`
- `Nero` → `Black`
- `Umano` → `Human`
- `Computer` → `Computer`

## Piece Terms

- `Re` → `King`
- `Dama` → `Queen`
- `Torre` → `Rook`
- `Alfiere` → `Bishop`
- `Cavallo` → `Knight`
- `Pedone` → `Pawn`

## Rule for New Code

- Do not introduce Italian names for classes, methods, fields, variables, comments, or visible text.
- When no direct translation exists, prefer a clear English domain term and add it to this glossary.
